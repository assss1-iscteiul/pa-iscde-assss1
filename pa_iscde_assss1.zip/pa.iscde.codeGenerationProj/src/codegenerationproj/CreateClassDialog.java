package codegenerationproj;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import pt.iscte.pidesco.projectbrowser.model.PackageElement;

public class CreateClassDialog implements Runnable {

	private Display window;
	private PackageElement packageElement;
	
	public CreateClassDialog(PackageElement packageElement) {
		this.packageElement = packageElement;
	}

	@Override
	public void run() {
		window = new Display();
		Shell shell = new Shell(window);
		shell.setSize(600, 400);
		shell.setLayout(new RowLayout());
		shell.setText("Create new class on " + packageElement.getName() + ".");
		
		// contains button, text box and the check box
		Composite compositeWidget = new Composite(shell, SWT.NONE);

		compositeWidget.setLayout(new RowLayout(SWT.VERTICAL));

		// text box
		Text textField = new Text(compositeWidget, SWT.SINGLE);

		Button createClassButton = new Button(compositeWidget, SWT.PUSH);
		createClassButton.setText("Accept");

		// cancel button
		Button cancelButton = new Button(compositeWidget, SWT.PUSH);
		cancelButton.setText("Cancel");

		// checkbox to build main
		Button checkBox = new Button(compositeWidget, SWT.CHECK);
		checkBox.setText("Include Main");

		// listener for the create class button
		createClassButton.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				String path = packageElement.getFile().getAbsolutePath();

				// replace \ with \\

				String fixedPath = path.replace("\\", "\\\\");

				System.out.println(fixedPath);
				String className = textField.getText();

				if (!className.contains(" ")) {

					try (Writer writer = new BufferedWriter(new OutputStreamWriter(
							new FileOutputStream(fixedPath + "\\\\" + className + ".java"), "utf-8"))) {
//						String[] packageName = packageElement.getFile().toString().split("\\\\");
						String packageName = packageElement.toString();

						// define the package string. eg: package extensibility
						String packageString = "package " + packageName + ";";

						// write package at the beginning
						writer.write(packageString + "\r\n" + "\r\n");

						// write class
						writer.write("public class " + className + " {" + "\r\n" + "\r\n");

						// check if checkBox is selected and if it is add the main
						if (checkBox.getSelection()) { //
							writer.write("\tpublic static void main(String[] args) {\r\n" + "\t\t\r\n" + "\t}"
									+ "\r\n");
						}

						writer.write("}");
						writer.close();
						
					} catch (UnsupportedEncodingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				} else {
					MessageDialog.openWarning(shell, "Warning", "Please insert a valid class name.");
				}

				close();
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		cancelButton.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				close();
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub

			}
		});

		shell.open();
		while (!shell.isDisposed()) {
			if (!window.readAndDispatch())
				window.sleep();
		}
		window.dispose();

	}
	
	private void close() {
		window.dispose();
	}

}
