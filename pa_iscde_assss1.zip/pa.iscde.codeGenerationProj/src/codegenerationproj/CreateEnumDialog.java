package codegenerationproj;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import pt.iscte.pidesco.projectbrowser.model.PackageElement;

public class CreateEnumDialog implements Runnable {

	private Display window;
	private PackageElement packageElement;
	
	public CreateEnumDialog(PackageElement packageElement) {
		this.packageElement = packageElement;
	}

	@Override
	public void run() {
		window = new Display();
		Shell shell = new Shell(window);
		shell.setSize(600, 400);
		shell.setLayout(new RowLayout());
		shell.setText("Create new enum on " + packageElement.getName() + ".");
		
		// contains button, text box and the check box
		Composite compositeWidget = new Composite(shell, SWT.NONE);

		compositeWidget.setLayout(new RowLayout(SWT.VERTICAL));

		// text box
		Text textField = new Text(compositeWidget, SWT.SINGLE);

		Button createEnumButton = new Button(compositeWidget, SWT.PUSH);
		createEnumButton.setText("Accept");

		// cancel button
		Button cancelButton = new Button(compositeWidget, SWT.PUSH);
		cancelButton.setText("Cancel");

		// listener for the create enum button
		createEnumButton.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				String path = packageElement.getFile().getAbsolutePath();

				// replace \ with \\

				String fixedPath = path.replace("\\", "\\\\");

				System.out.println(fixedPath);
				String enumName = textField.getText();

				if (!enumName.contains(" ")) {

					try (Writer writer = new BufferedWriter(new OutputStreamWriter(
							new FileOutputStream(fixedPath + "\\\\" + enumName + ".java"), "utf-8"))) {
//						String[] packageName = packageElement.getFile().toString().split("\\\\");
						String packageName = packageElement.toString();

						// define the package string. eg: package extensibility
						String packageString = "package " + packageName + ";";

						// write package at the beginning
						writer.write(packageString + "\r\n" + "\r\n");

						// write enum
						writer.write("public enum " + enumName + " {" + "\r\n" + "\r\n");

						writer.write("}");
						writer.close();
						
					} catch (UnsupportedEncodingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				} else {
					MessageDialog.openWarning(shell, "Warning", "Please insert a valid enum name.");
				}

				close();
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		cancelButton.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				close();
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub

			}
		});

		shell.open();
		while (!shell.isDisposed()) {
			if (!window.readAndDispatch())
				window.sleep();
		}
		window.dispose();

	}
	
	private void close() {
		window.dispose();
	}

}
